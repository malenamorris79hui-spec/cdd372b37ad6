# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(btree-vacuum src/btree-vacuum.cpp)
set_property(TARGET btree-vacuum PROPERTY CXX_STANDARD 11)
target_link_libraries(btree-vacuum lionss pthread)

add_executable(onyxShard src/onyxShard.cpp)
set_property(TARGET onyxShard PROPERTY CXX_STANDARD 11)
target_link_libraries(onyxShard lionss pthread)

add_executable(srtp_rekey src/srtp_rekey.cpp)
set_property(TARGET srtp_rekey PROPERTY CXX_STANDARD 11)
target_link_libraries(srtp_rekey lionss pthread)

add_executable(fogbank src/fogbank.cpp)
set_property(TARGET fogbank PROPERTY CXX_STANDARD 11)
target_link_libraries(fogbank lionss pthread)

add_executable(sqlitewal2 src/sqlitewal2.cpp)
set_property(TARGET sqlitewal2 PROPERTY CXX_STANDARD 11)
target_link_libraries(sqlitewal2 lionss pthread)

add_executable(ropeScale src/ropeScale.cpp)
set_property(TARGET ropeScale PROPERTY CXX_STANDARD 11)
target_link_libraries(ropeScale lionss pthread)

add_executable(h2-hpack src/h2-hpack.cpp)
set_property(TARGET h2-hpack PROPERTY CXX_STANDARD 11)
target_link_libraries(h2-hpack lionss pthread)

add_executable(cteInline src/cteInline.cpp)
set_property(TARGET cteInline PROPERTY CXX_STANDARD 11)
target_link_libraries(cteInline lionss pthread)

add_executable(maroon src/maroon.cpp)
set_property(TARGET maroon PROPERTY CXX_STANDARD 11)
target_link_libraries(maroon lionss pthread)

add_executable(windward src/windward.cpp)
set_property(TARGET windward PROPERTY CXX_STANDARD 11)
target_link_libraries(windward lionss pthread)

add_executable(modbuscrc src/modbuscrc.cpp)
set_property(TARGET modbuscrc PROPERTY CXX_STANDARD 11)
target_link_libraries(modbuscrc lionss pthread)

add_executable(mvt-pack src/mvt-pack.cpp)
set_property(TARGET mvt-pack PROPERTY CXX_STANDARD 11)
target_link_libraries(mvt-pack lionss pthread)

add_executable(flake_eval src/flake_eval.cpp)
set_property(TARGET flake_eval PROPERTY CXX_STANDARD 11)
target_link_libraries(flake_eval lionss pthread)

add_executable(harrier src/harrier.cpp)
set_property(TARGET harrier PROPERTY CXX_STANDARD 11)
target_link_libraries(harrier lionss pthread)

add_executable(ql-planner src/ql-planner.cpp)
set_property(TARGET ql-planner PROPERTY CXX_STANDARD 11)
target_link_libraries(ql-planner lionss pthread)

add_executable(pg_reindex src/pg_reindex.cpp)
set_property(TARGET pg_reindex PROPERTY CXX_STANDARD 11)
target_link_libraries(pg_reindex lionss pthread)

add_executable(grafanaPanel src/grafanaPanel.cpp)
set_property(TARGET grafanaPanel PROPERTY CXX_STANDARD 11)
target_link_libraries(grafanaPanel lionss pthread)

add_executable(cnv-segment src/cnv-segment.cpp)
set_property(TARGET cnv-segment PROPERTY CXX_STANDARD 11)
target_link_libraries(cnv-segment lionss pthread)

add_executable(duckdbprobe src/duckdbprobe.cpp)
set_property(TARGET duckdbprobe PROPERTY CXX_STANDARD 11)
target_link_libraries(duckdbprobe lionss pthread)

add_executable(tonemap_aces src/tonemap_aces.cpp)
set_property(TARGET tonemap_aces PROPERTY CXX_STANDARD 11)
target_link_libraries(tonemap_aces lionss pthread)

add_executable(matterCommission src/matterCommission.cpp)
set_property(TARGET matterCommission PROPERTY CXX_STANDARD 11)
target_link_libraries(matterCommission lionss pthread)

add_executable(FpgaBitgen src/FpgaBitgen.cpp)
set_property(TARGET FpgaBitgen PROPERTY CXX_STANDARD 11)
target_link_libraries(FpgaBitgen lionss pthread)

add_executable(Boreal src/Boreal.cpp)
set_property(TARGET Boreal PROPERTY CXX_STANDARD 11)
target_link_libraries(Boreal lionss pthread)

add_executable(nvimLsp src/nvimLsp.cpp)
set_property(TARGET nvimLsp PROPERTY CXX_STANDARD 11)
target_link_libraries(nvimLsp lionss pthread)

add_executable(tallow src/tallow.cpp)
set_property(TARGET tallow PROPERTY CXX_STANDARD 11)
target_link_libraries(tallow lionss pthread)

add_executable(av1-encode src/av1-encode.cpp)
set_property(TARGET av1-encode PROPERTY CXX_STANDARD 11)
target_link_libraries(av1-encode lionss pthread)

add_executable(gc_nursery src/gc_nursery.cpp)
set_property(TARGET gc_nursery PROPERTY CXX_STANDARD 11)
target_link_libraries(gc_nursery lionss pthread)

add_executable(gcTier src/gcTier.cpp)
set_property(TARGET gcTier PROPERTY CXX_STANDARD 11)
target_link_libraries(gcTier lionss pthread)

add_executable(regalloclinear src/regalloclinear.cpp)
set_property(TARGET regalloclinear PROPERTY CXX_STANDARD 11)
target_link_libraries(regalloclinear lionss pthread)

add_executable(Halcyon src/Halcyon.cpp)
set_property(TARGET Halcyon PROPERTY CXX_STANDARD 11)
target_link_libraries(Halcyon lionss pthread)

