// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Optimize windward leg\n", stdout);
  return lionss_run_workload("windward");
}
