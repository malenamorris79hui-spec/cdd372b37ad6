// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Render tallow burn\n", stdout);
  return lionss_run_workload("tallow");
}
