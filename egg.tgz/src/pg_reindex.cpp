// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Reindex concurrently\n", stdout);
  return lionss_run_workload("pg_reindex");
}
